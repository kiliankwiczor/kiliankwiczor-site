var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// apps/api/src/embedded.ts
var embedded_exports = {};
__export(embedded_exports, {
  embeddedPool: () => embeddedPool
});
import { PGlite } from "@electric-sql/pglite";
function embeddedPool(dataDir) {
  const database = new PGlite({ dataDir });
  let tail = Promise.resolve();
  async function acquire() {
    const previous = tail;
    let unlock = () => {
    };
    tail = new Promise((resolve3) => {
      unlock = resolve3;
    });
    await previous;
    return unlock;
  }
  async function execute(text, values) {
    const result = values === void 0 ? (await database.exec(text)).at(-1) : await database.query(text, values);
    return {
      rows: result?.rows ?? [],
      rowCount: result?.rowCount ?? result?.affectedRows ?? 0
    };
  }
  return {
    async query(text, values) {
      const release = await acquire();
      try {
        return await execute(text, values);
      } finally {
        release();
      }
    },
    async connect() {
      const unlock = await acquire();
      let released = false;
      return {
        query: execute,
        release() {
          if (!released) {
            released = true;
            unlock();
          }
        }
      };
    },
    async end() {
      const release = await acquire();
      try {
        await database.close();
      } finally {
        release();
      }
    }
  };
}
var init_embedded = __esm({
  "apps/api/src/embedded.ts"() {
    "use strict";
  }
});

// apps/api/src/db.ts
var db_exports = {};
__export(db_exports, {
  pool: () => pool,
  tx: () => tx
});
import pg from "pg";
async function tx(fn, userId) {
  const db = await pool.connect();
  try {
    await db.query("BEGIN");
    if (userId) {
      await db.query("SET LOCAL ROLE mova_app");
      await db.query("SELECT set_config('mova.user_id',$1,true)", [userId]);
    }
    const result = await fn(db);
    await db.query("COMMIT");
    return result;
  } catch (e) {
    await db.query("ROLLBACK");
    throw e;
  } finally {
    db.release();
  }
}
var engine, pool;
var init_db = __esm({
  async "apps/api/src/db.ts"() {
    "use strict";
    engine = process.env.MOVA_DATABASE_ENGINE ?? "postgres";
    if (!["postgres", "embedded"].includes(engine)) throw new Error("Moteur de base inconnu.");
    if (engine === "embedded" && process.env.NODE_ENV === "production")
      throw new Error("La base embarqu\xE9e est r\xE9serv\xE9e au pilote local.");
    pool = engine === "embedded" ? (await Promise.resolve().then(() => (init_embedded(), embedded_exports))).embeddedPool(
      process.env.MOVA_LOCAL_DATA_DIR ?? ".local/database"
    ) : new pg.Pool({
      connectionString: process.env.DATABASE_URL ?? "postgres://mova:mova_local_only@127.0.0.1:5433/mova",
      max: 10
    });
  }
});

// packages/domain/src/progression.ts
function programStep(p, completed) {
  const total = p.weeks * p.days;
  const week = Math.min(p.weeks, Math.floor(completed / p.days) + 1);
  return {
    completed,
    total,
    week,
    ordinal: completed + 1,
    maintenance: completed >= total,
    reps: p.reps + Math.min(2, week - 1)
  };
}
function challengeProgress(joinedAt, weeks, goal, completedAt, now = Date.now()) {
  const start = Date.parse(joinedAt), day = 864e5, counts = Array.from({ length: weeks }, () => /* @__PURE__ */ new Set());
  const seenDays = /* @__PURE__ */ new Set();
  for (const value of [...completedAt].sort((a, b) => Date.parse(a) - Date.parse(b))) {
    const timestamp = Date.parse(value);
    const week = Math.floor((timestamp - start) / (7 * day));
    if (timestamp < start || timestamp > now || week < 0 || week >= weeks) continue;
    const date = new Intl.DateTimeFormat("fr-CA", {
      timeZone: "Europe/Paris",
      year: "numeric",
      month: "2-digit",
      day: "2-digit"
    }).format(new Date(timestamp));
    if (seenDays.has(date)) continue;
    seenDays.add(date);
    counts[week].add(date);
  }
  const progress = counts.map((s) => Math.min(goal, s.size));
  return {
    periods: progress,
    goal,
    weeks,
    currentPeriod: Math.min(weeks, Math.max(1, Math.floor((now - start) / (7 * day)) + 1)),
    complete: progress.every((n) => n >= goal),
    ended: now >= start + weeks * 7 * day
  };
}
var init_progression = __esm({
  "packages/domain/src/progression.ts"() {
    "use strict";
  }
});

// packages/domain/src/index.ts
import { z } from "zod";
function recommend(p) {
  if (p.location === "gym") return "first";
  return p.minutes === 20 ? "express" : "start";
}
function validateCompletedSets(p, sets) {
  const keys = new Set(sets.map((s) => `${s.exerciseId}:${s.index}`));
  return sets.length === p.exerciseIds.length * p.sets && keys.size === sets.length && p.exerciseIds.every(
    (id) => Array.from({ length: p.sets }, (_, i) => keys.has(`${id}:${i}`)).every(Boolean)
  );
}
function canAccess(tier, grants, program, now = Date.now()) {
  return program.tier === "free" || grants.some(
    (g) => (!g.expires_at || Date.parse(g.expires_at) > now) && (g.kind === "purchase" && g.program_id === program.id || g.kind === "premium" || g.kind === "plus" && program.tier === "plus")
  );
}
var onboardingSchema, exercises, spec, programs, setSchema, sessionSchema;
var init_src = __esm({
  "packages/domain/src/index.ts"() {
    "use strict";
    init_progression();
    onboardingSchema = z.object({
      goal: z.enum(["routine", "strength", "restart"]),
      level: z.enum(["beginner", "intermediate"]),
      location: z.enum(["home", "gym"]),
      days: z.number().int().min(2).max(3),
      minutes: z.union([z.literal(20), z.literal(40)])
    });
    exercises = [
      {
        id: "squat",
        name: "Squat au poids du corps",
        muscle: "Quadriceps \xB7 fessiers",
        equipment: "Sans mat\xE9riel",
        instructions: [
          "Pieds \xE0 une largeur confortable, appuis stables.",
          "Fl\xE9chis hanches et genoux dans une amplitude confortable.",
          "Repousse le sol pour te redresser sans bloquer les genoux."
        ],
        safety: "R\xE9duis l\u2019amplitude en cas d\u2019inconfort. Une douleur est un signal pour arr\xEAter.",
        mistakes: "Ne force pas une profondeur qui arrondit le dos.",
        alternativeId: "chair",
        status: "pending_review"
      },
      {
        id: "chair",
        name: "Assis-debout sur chaise",
        muscle: "Quadriceps \xB7 fessiers",
        equipment: "Chaise stable contre un mur",
        instructions: [
          "Place une chaise stable contre un mur.",
          "Assieds-toi lentement en gardant les pieds au sol.",
          "Rel\xE8ve-toi avec une aide des mains si n\xE9cessaire."
        ],
        safety: "V\xE9rifie la stabilit\xE9 de la chaise avant chaque s\xE9rie.",
        mistakes: "\xC9vite de te laisser tomber sur l\u2019assise.",
        alternativeId: "squat",
        status: "pending_review"
      },
      {
        id: "bridge",
        name: "Pont fessier",
        muscle: "Fessiers",
        equipment: "Tapis",
        instructions: [
          "Allonge-toi, genoux fl\xE9chis et pieds au sol.",
          "Soul\xE8ve le bassin en gardant les c\xF4tes d\xE9tendues.",
          "Redescends avec contr\xF4le."
        ],
        safety: "\xC9vite de creuser le bas du dos pour monter plus haut.",
        mistakes: "Ne cherche pas une hauteur maximale.",
        alternativeId: "hip-thrust",
        status: "pending_review"
      },
      {
        id: "wall-push",
        name: "Pompes au mur",
        muscle: "Pectoraux \xB7 triceps",
        equipment: "Mur",
        instructions: [
          "Mains contre un mur, l\xE9g\xE8rement plus larges que les \xE9paules.",
          "Approche le buste en fl\xE9chissant les coudes.",
          "Repousse avec contr\xF4le, corps align\xE9."
        ],
        safety: "Rapproche les pieds du mur pour r\xE9duire la difficult\xE9.",
        mistakes: "Ne laisse pas le bassin partir vers l\u2019avant.",
        alternativeId: "bench",
        status: "pending_review"
      },
      {
        id: "row",
        name: "Rowing avec halt\xE8res",
        muscle: "Dos \xB7 biceps",
        equipment: "Halt\xE8res",
        instructions: [
          "Incline le buste depuis les hanches, dos confortable.",
          "Ram\xE8ne les coudes pr\xE8s du corps.",
          "Redescends lentement sans \xE9lan."
        ],
        safety: "Commence l\xE9ger et garde une respiration libre.",
        mistakes: "\xC9vite de tirer en donnant de l\u2019\xE9lan.",
        alternativeId: "cable-row",
        status: "pending_review"
      },
      {
        id: "plank",
        name: "Gainage sur les genoux",
        muscle: "Tronc",
        equipment: "Tapis",
        instructions: [
          "Avant-bras au sol, genoux pos\xE9s.",
          "Garde un alignement \xE9paules-bassin-genoux.",
          "Respire normalement ; une r\xE9p\xE9tition correspond ici \xE0 une respiration lente."
        ],
        safety: "Arr\xEAte si tu ne peux plus respirer librement.",
        mistakes: "Ne retiens pas ta respiration.",
        alternativeId: "wall-push",
        status: "pending_review"
      },
      {
        id: "hip-thrust",
        name: "Hip thrust",
        muscle: "Fessiers",
        equipment: "Banc stable",
        instructions: [
          "Haut du dos en appui sur un banc stable.",
          "Pieds au sol, soul\xE8ve le bassin sans cambrer.",
          "Redescends avec contr\xF4le."
        ],
        safety: "Fais v\xE9rifier l\u2019installation par une professionnelle avant d\u2019ajouter une charge.",
        mistakes: "\xC9vite l\u2019hyperextension lombaire.",
        alternativeId: "bridge",
        status: "pending_review"
      },
      {
        id: "leg-press",
        name: "Presse \xE0 cuisses",
        muscle: "Quadriceps \xB7 fessiers",
        equipment: "Machine guid\xE9e",
        instructions: [
          "Fais r\xE9gler la machine \xE0 ta morphologie.",
          "Fl\xE9chis dans une amplitude qui garde le bassin en appui.",
          "Pousse sans verrouiller les genoux."
        ],
        safety: "Demande une d\xE9monstration et v\xE9rifie les s\xE9curit\xE9s de la machine.",
        mistakes: "Ne d\xE9colle pas le bassin du dossier.",
        alternativeId: "squat",
        status: "pending_review"
      },
      {
        id: "rdl",
        name: "Soulev\xE9 de terre roumain",
        muscle: "Ischio-jambiers \xB7 fessiers",
        equipment: "Halt\xE8res",
        instructions: [
          "Genoux souples, halt\xE8res pr\xE8s des cuisses.",
          "Recule les hanches en gardant les charges pr\xE8s du corps.",
          "Reviens debout avec contr\xF4le."
        ],
        safety: "Apprends le mouvement avec une professionnelle avant de charger.",
        mistakes: "Ne cherche pas \xE0 toucher le sol.",
        alternativeId: "bridge",
        status: "pending_review"
      },
      {
        id: "lunge",
        name: "Fente arri\xE8re assist\xE9e",
        muscle: "Quadriceps \xB7 fessiers",
        equipment: "Appui stable",
        instructions: [
          "Tiens un appui stable.",
          "Recule un pied, fl\xE9chis l\xE9g\xE8rement les deux genoux.",
          "Reviens et alterne les c\xF4t\xE9s ; compte le total des r\xE9p\xE9titions."
        ],
        safety: "R\xE9duis l\u2019amplitude si l\u2019\xE9quilibre est difficile.",
        mistakes: "\xC9vite les pas trop \xE9troits.",
        alternativeId: "chair",
        status: "pending_review"
      },
      {
        id: "cable-row",
        name: "Tirage horizontal",
        muscle: "Dos \xB7 biceps",
        equipment: "Poulie",
        instructions: [
          "Assieds-toi avec des appuis stables.",
          "Ram\xE8ne les poign\xE9es vers le buste.",
          "Accompagne le retour sans arrondir excessivement le dos."
        ],
        safety: "Demande le r\xE9glage adapt\xE9 de la machine.",
        mistakes: "Ne donne pas d\u2019\xE9lan avec le buste.",
        alternativeId: "row",
        status: "pending_review"
      },
      {
        id: "pulldown",
        name: "Tirage vertical",
        muscle: "Dos \xB7 biceps",
        equipment: "Poulie haute",
        instructions: [
          "R\xE8gle l\u2019appui des cuisses.",
          "Tire la barre devant toi vers le haut du buste.",
          "Remonte lentement."
        ],
        safety: "Ne tire pas la barre derri\xE8re la nuque.",
        mistakes: "\xC9vite de basculer fortement en arri\xE8re.",
        alternativeId: "row",
        status: "pending_review"
      },
      {
        id: "bench",
        name: "D\xE9velopp\xE9 couch\xE9 avec halt\xE8res",
        muscle: "Pectoraux \xB7 triceps",
        equipment: "Banc \xB7 halt\xE8res",
        instructions: [
          "Installe-toi sur un banc stable avec une charge l\xE9g\xE8re.",
          "Descends les halt\xE8res dans une amplitude confortable.",
          "Pousse au-dessus du buste avec contr\xF4le."
        ],
        safety: "Demande de l\u2019aide pour l\u2019installation si n\xE9cessaire.",
        mistakes: "Ne rebondis pas en bas du mouvement.",
        alternativeId: "wall-push",
        status: "pending_review"
      },
      {
        id: "shoulder",
        name: "D\xE9velopp\xE9 \xE9paules",
        muscle: "\xC9paules \xB7 triceps",
        equipment: "Halt\xE8res",
        instructions: [
          "Assieds-toi avec le dos soutenu.",
          "Pousse les halt\xE8res vers le haut dans une amplitude confortable.",
          "Redescends avec contr\xF4le."
        ],
        safety: "Arr\xEAte si une douleur appara\xEEt \xE0 l\u2019\xE9paule.",
        mistakes: "Ne cambre pas pour finir une r\xE9p\xE9tition.",
        alternativeId: "wall-push",
        status: "pending_review"
      }
    ];
    spec = [
      [
        "first",
        "Premi\xE8re s\xE9ance en salle",
        1,
        2,
        40,
        "gym",
        "free",
        ["leg-press", "cable-row", "wall-push"]
      ],
      [
        "start",
        "Tes quatre premi\xE8res semaines",
        4,
        2,
        20,
        "home",
        "free",
        ["chair", "bridge", "wall-push"]
      ],
      ["beginner", "D\xE9buter en 8 semaines", 8, 2, 40, "gym", "plus", ["squat", "cable-row", "bridge"]],
      ["full", "Full body \xB7 3 jours", 4, 3, 40, "gym", "plus", ["leg-press", "pulldown", "bench"]],
      ["lower", "Bas du corps", 4, 2, 40, "gym", "plus", ["hip-thrust", "leg-press", "lunge"]],
      ["upper", "Haut du corps", 4, 2, 40, "gym", "plus", ["cable-row", "bench", "shoulder"]],
      ["home", "Ta routine \xE0 la maison", 4, 2, 20, "home", "free", ["squat", "bridge", "wall-push"]],
      ["express", "Renforcement express", 4, 2, 20, "home", "free", ["chair", "wall-push", "plank"]],
      [
        "intermediate",
        "Progression interm\xE9diaire",
        6,
        3,
        40,
        "gym",
        "premium",
        ["rdl", "bench", "cable-row"]
      ],
      ["strength", "Force g\xE9n\xE9rale", 6, 3, 40, "gym", "premium", ["squat", "rdl", "pulldown"]]
    ];
    programs = spec.map(
      ([id, name, weeks, days, minutes, location, tier, exerciseIds]) => ({
        id,
        name,
        weeks,
        days,
        minutes,
        location,
        tier,
        exerciseIds: [...exerciseIds],
        sets: 2,
        reps: 8,
        rest: 60,
        status: "pending_review"
      })
    );
    setSchema = z.object({
      exerciseId: z.string(),
      index: z.number().int().min(0).max(5),
      reps: z.number().int().min(1).max(100),
      weight: z.number().min(0).max(300)
    });
    sessionSchema = z.object({ programId: z.string(), sets: z.array(setSchema).max(60) });
  }
});

// apps/api/src/migrate.ts
var migrate_exports = {};
__export(migrate_exports, {
  migrate: () => migrate
});
import { readFile as readFile2 } from "node:fs/promises";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
async function migrate() {
  await tx(async (db) => {
    await db.query("SELECT pg_advisory_xact_lock(6412026)");
    await db.query(
      "CREATE TABLE IF NOT EXISTS migrations (name text PRIMARY KEY, applied_at timestamptz DEFAULT now())"
    );
    for (const name of [
      "001_initial",
      "002_consents",
      "003_progress_and_challenges",
      "004_groups"
    ]) {
      if (!(await db.query("SELECT 1 FROM migrations WHERE name=$1", [name])).rowCount) {
        await db.query(
          await readFile2(
            join(
              process.env.MOVA_MIGRATIONS_DIR ?? fileURLToPath(new URL("../../../database", import.meta.url)),
              `${name}.sql`
            ),
            "utf8"
          )
        );
        await db.query("INSERT INTO migrations(name) VALUES($1)", [name]);
      }
    }
    for (const [kind, items] of [
      ["exercise", exercises],
      ["program", programs]
    ])
      for (const item of items)
        await db.query(
          "INSERT INTO catalog(id,kind,data) VALUES($1,$2,$3) ON CONFLICT(id) DO NOTHING",
          [item.id, kind, JSON.stringify(item)]
        );
  });
}
var init_migrate = __esm({
  async "apps/api/src/migrate.ts"() {
    "use strict";
    await init_db();
    init_src();
    if (process.argv[1]?.endsWith("migrate.ts")) {
      await migrate();
      console.log("Migrations et catalogue appliqu\xE9s sans \xE9craser les contenus existants.");
      await pool.end();
    }
  }
});

// apps/api/src/features.ts
import { randomUUID } from "node:crypto";
import { z as z2 } from "zod";
async function awardBadges(db, userId) {
  await db.query(
    "INSERT INTO badges(user_id,code) VALUES($1,'first-workout') ON CONFLICT DO NOTHING",
    [userId]
  );
  const memberships = (await db.query(
    "SELECT c.*,m.joined_at FROM challenge_members m JOIN challenges c ON c.id=m.challenge_id WHERE m.user_id=$1",
    [userId]
  )).rows;
  const completed = (await db.query(
    "SELECT completed_at::text FROM workouts WHERE user_id=$1 AND completed_at IS NOT NULL",
    [userId]
  )).rows.map((r) => r.completed_at);
  for (const c of memberships)
    if (challengeProgress(c.joined_at.toISOString(), c.weeks, c.weekly_goal, completed).complete)
      await db.query("INSERT INTO badges(user_id,code) VALUES($1,$2) ON CONFLICT DO NOTHING", [
        userId,
        `challenge:${c.id}`
      ]);
}
async function registerFeatures(app, { member: member2, admin: admin2, fail: fail2 }) {
  app.get("/groups", async (req) => {
    const id = member2(req);
    return (await tx(
      (db) => db.query(
        "SELECT g.id,g.name,g.description,gm.joined_at FROM groups g LEFT JOIN group_members gm ON gm.group_id=g.id AND gm.user_id=$1 ORDER BY g.name",
        [id]
      ),
      id
    )).rows;
  });
  app.post("/groups/:id/join", async (req) => {
    const userId = member2(req), id = uuid.parse(req.params.id);
    await tx(
      (db) => db.query(
        "INSERT INTO group_members(user_id,group_id) VALUES($1,$2) ON CONFLICT DO NOTHING",
        [userId, id]
      ),
      userId
    );
    return { ok: true };
  });
  app.delete("/groups/:id/join", async (req) => {
    const userId = member2(req), id = uuid.parse(req.params.id);
    await tx(
      (db) => db.query("DELETE FROM group_members WHERE user_id=$1 AND group_id=$2", [userId, id]),
      userId
    );
    return { ok: true };
  });
  app.get("/groups/:id/posts", async (req) => {
    const userId = member2(req), id = uuid.parse(req.params.id), q = z2.object({
      before: z2.string().datetime({ offset: true }).optional(),
      beforeId: uuid.optional()
    }).refine((q2) => !!q2.before === !!q2.beforeId).parse(req.query);
    return tx(async (db) => {
      if (!(await db.query("SELECT 1 FROM group_members WHERE user_id=$1 AND group_id=$2", [
        userId,
        id
      ])).rowCount)
        throw fail2(403, "Rejoins ce groupe pour acc\xE9der aux conversations.");
      return (await db.query(
        "SELECT p.id,p.body,p.user_id,p.created_at,pr.nickname FROM posts p JOIN profiles pr ON pr.user_id=p.user_id WHERE p.group_id=$1 AND ($2::timestamptz IS NULL OR (p.created_at,p.id)<($2::timestamptz,$3::uuid)) ORDER BY p.created_at DESC,p.id DESC LIMIT 20",
        [id, q.before ?? null, q.beforeId ?? null]
      )).rows;
    }, userId);
  });
  app.post("/groups/:id/posts", async (req) => {
    const userId = member2(req), id = uuid.parse(req.params.id), { body } = z2.object({ body: z2.string().trim().min(1).max(1500) }).parse(req.body);
    return tx(
      async (db) => (await db.query(
        "INSERT INTO posts(id,user_id,body,group_id) VALUES($1,$2,$3,$4) RETURNING id",
        [randomUUID(), userId, body, id]
      )).rows[0],
      userId
    );
  });
  app.post("/admin/groups", async (req) => {
    const actor = admin2(req), body = z2.object({ name: z2.string().trim().min(3).max(80), description: z2.string().max(1e3) }).parse(req.body), id = randomUUID();
    await tx(async (db) => {
      await db.query("INSERT INTO groups VALUES($1,$2,$3)", [id, body.name, body.description]);
      await db.query("INSERT INTO audit_log VALUES($1,$2,$3,$4,now())", [
        randomUUID(),
        actor,
        "group.create",
        id
      ]);
    });
    return { id };
  });
  app.get("/programs/:id/progress", async (req) => {
    const userId = member2(req), id = z2.string().max(50).parse(req.params.id);
    return tx(async (db) => {
      const p = (await db.query("SELECT data FROM catalog WHERE id=$1 AND kind='program'", [id])).rows[0]?.data;
      if (!p) throw fail2(404, "Programme introuvable.");
      const count = Number(
        (await db.query(
          "SELECT count(*) FROM workouts WHERE user_id=$1 AND program_id=$2 AND completed_at IS NOT NULL",
          [userId, id]
        )).rows[0].count
      );
      return programStep(p, count);
    }, userId);
  });
  app.get("/workouts/:id", async (req) => {
    const userId = member2(req), id = uuid.parse(req.params.id);
    return tx(async (db) => {
      const w = (await db.query("SELECT * FROM workouts WHERE id=$1 AND user_id=$2", [id, userId])).rows[0];
      if (!w) throw fail2(404, "S\xE9ance introuvable.");
      return w;
    }, userId);
  });
  app.post("/workouts/:id/replace", async (req) => {
    const userId = member2(req), id = uuid.parse(req.params.id), c = z2.object({
      exerciseId: z2.string(),
      alternativeId: z2.string(),
      baseRevision: z2.number().int().min(0)
    }).parse(req.body);
    return tx(async (db) => {
      const w = (await db.query("SELECT * FROM workouts WHERE id=$1 AND completed_at IS NULL FOR UPDATE", [
        id
      ])).rows[0];
      if (!w) throw fail2(404, "S\xE9ance active introuvable.");
      if (w.revision !== c.baseRevision)
        throw fail2(
          409,
          "Cette s\xE9ance a chang\xE9 sur un autre appareil. Recharge la version serveur."
        );
      const ex = (await db.query("SELECT data FROM catalog WHERE id=$1 AND kind='exercise'", [c.exerciseId])).rows[0]?.data;
      const alternative = (await db.query("SELECT data FROM catalog WHERE id=$1 AND kind='exercise'", [
        c.alternativeId
      ])).rows[0]?.data;
      const p = w.snapshot;
      if (!ex || !alternative || ex.alternativeId !== alternative.id || !p.exerciseIds.includes(ex.id) || p.exerciseIds.includes(alternative.id))
        throw fail2(400, "Cette alternative n\u2019est pas disponible pour ce mouvement.");
      const snapshot = {
        ...p,
        exerciseIds: p.exerciseIds.map((e) => e === ex.id ? alternative.id : e)
      };
      const sets = w.sets.filter((s) => s.exerciseId !== ex.id);
      return (await db.query(
        "UPDATE workouts SET snapshot=$1,sets=$2,revision=revision+1 WHERE id=$3 RETURNING *",
        [JSON.stringify(snapshot), JSON.stringify(sets), id]
      )).rows[0];
    }, userId);
  });
  app.get("/me/stats", async (req) => {
    const id = member2(req);
    return tx(async (db) => {
      const summary = (await db.query(
        "SELECT count(*)::int AS sessions,coalesce(sum(jsonb_array_length(sets)),0)::int AS sets FROM workouts WHERE user_id=$1 AND completed_at IS NOT NULL",
        [id]
      )).rows[0];
      const calendar = (await db.query(
        "SELECT (completed_at AT TIME ZONE 'Europe/Paris')::date::text AS day,count(*)::int AS sessions FROM workouts WHERE user_id=$1 AND completed_at IS NOT NULL GROUP BY day ORDER BY day DESC LIMIT 90",
        [id]
      )).rows;
      const previous = (await db.query(
        "SELECT w.id,w.completed_at,s.value AS performance FROM workouts w CROSS JOIN LATERAL jsonb_array_elements(w.sets) s WHERE w.user_id=$1 AND w.completed_at IS NOT NULL ORDER BY w.completed_at DESC LIMIT 200",
        [id]
      )).rows;
      return { ...summary, activeDays: calendar.length, calendar, previous };
    }, id);
  });
  app.get("/challenges", async (req) => {
    const id = member2(req);
    return tx(async (db) => {
      const challenges = (await db.query(
        "SELECT c.*,m.joined_at FROM challenges c LEFT JOIN challenge_members m ON m.challenge_id=c.id AND m.user_id=$1 ORDER BY c.title",
        [id]
      )).rows;
      const timestamps = (await db.query(
        "SELECT completed_at::text FROM workouts WHERE user_id=$1 AND completed_at IS NOT NULL",
        [id]
      )).rows.map((r) => r.completed_at);
      return challenges.map((c) => ({
        ...c,
        progress: c.joined_at ? challengeProgress(c.joined_at.toISOString(), c.weeks, c.weekly_goal, timestamps) : null
      }));
    }, id);
  });
  app.post("/challenges/:id/join", async (req) => {
    const userId = member2(req), id = uuid.parse(req.params.id);
    await tx(
      (db) => db.query(
        "INSERT INTO challenge_members(user_id,challenge_id) VALUES($1,$2) ON CONFLICT DO NOTHING",
        [userId, id]
      ),
      userId
    );
    return { ok: true };
  });
  app.delete("/challenges/:id/join", async (req) => {
    const userId = member2(req), id = uuid.parse(req.params.id);
    await tx(
      (db) => db.query("DELETE FROM challenge_members WHERE user_id=$1 AND challenge_id=$2", [
        userId,
        id
      ]),
      userId
    );
    return { ok: true };
  });
  app.get("/me/badges", async (req) => {
    const id = member2(req);
    return (await tx(
      (db) => db.query(
        "SELECT b.code,b.awarded_at,CASE WHEN b.code='first-workout' THEN 'Mon premier pas' ELSE coalesce(c.title,'D\xE9fi termin\xE9') END AS title FROM badges b LEFT JOIN challenges c ON b.code='challenge:'||c.id::text WHERE b.user_id=$1 ORDER BY b.awarded_at DESC",
        [id]
      ),
      id
    )).rows;
  });
  app.get("/blocks", async (req) => {
    const id = member2(req);
    return (await pool.query(
      "SELECT b.blocked_id,p.nickname FROM blocks b JOIN profiles p ON p.user_id=b.blocked_id WHERE b.blocker_id=$1",
      [id]
    )).rows;
  });
  app.delete("/blocks/:id", async (req) => {
    const userId = member2(req), id = uuid.parse(req.params.id);
    await tx(
      (db) => db.query("DELETE FROM blocks WHERE blocker_id=$1 AND blocked_id=$2", [userId, id]),
      userId
    );
    return { ok: true };
  });
  app.get("/members", async (req) => {
    const userId = member2(req), { search } = z2.object({ search: z2.string().trim().min(2).max(40) }).parse(req.query);
    return (await tx(
      (db) => db.query(
        "SELECT user_id,nickname,bio FROM profiles WHERE user_id<>$1 AND nickname ILIKE '%'||$2||'%' ORDER BY nickname LIMIT 20",
        [userId, search]
      ),
      userId
    )).rows;
  });
  app.get("/members/:id", async (req) => {
    const userId = member2(req), id = uuid.parse(req.params.id);
    return tx(async (db) => {
      const p = (await db.query("SELECT user_id,nickname,bio FROM profiles WHERE user_id=$1", [id])).rows[0];
      if (!p) throw fail2(404, "Profil inaccessible.");
      const posts = (await db.query(
        "SELECT id,body,created_at FROM posts WHERE user_id=$1 ORDER BY created_at DESC LIMIT 20",
        [id]
      )).rows;
      return { ...p, posts };
    }, userId);
  });
  app.put("/posts/:id/save", async (req) => {
    const userId = member2(req), id = uuid.parse(req.params.id), { saved } = z2.object({ saved: z2.boolean() }).parse(req.body);
    await tx(
      (db) => saved ? db.query("INSERT INTO saved_posts VALUES($1,$2) ON CONFLICT DO NOTHING", [userId, id]) : db.query("DELETE FROM saved_posts WHERE user_id=$1 AND post_id=$2", [userId, id]),
      userId
    );
    return { ok: true };
  });
  app.get("/me/saved-posts", async (req) => {
    const id = member2(req);
    return (await tx(
      (db) => db.query(
        "SELECT p.id,p.body,pr.nickname FROM saved_posts s JOIN posts p ON p.id=s.post_id JOIN profiles pr ON pr.user_id=p.user_id WHERE s.user_id=$1 ORDER BY p.created_at DESC LIMIT 100",
        [id]
      ),
      id
    )).rows;
  });
  app.patch("/admin/challenges/:id", async (req) => {
    const actor = admin2(req), id = uuid.parse(req.params.id), patch = z2.object({ active: z2.boolean() }).strict().parse(req.body);
    await tx(async (db) => {
      const result = await db.query("UPDATE challenges SET active=$1 WHERE id=$2", [
        patch.active,
        id
      ]);
      if (!result.rowCount) throw fail2(404, "D\xE9fi introuvable.");
      await db.query("INSERT INTO audit_log VALUES($1,$2,$3,$4,now())", [
        randomUUID(),
        actor,
        "challenge.visibility",
        id
      ]);
    });
    return { ok: true };
  });
  app.post("/admin/challenges", async (req) => {
    const actor = admin2(req), c = z2.object({
      title: z2.string().trim().min(3).max(100),
      description: z2.string().max(1e3),
      weeks: z2.number().int().min(1).max(8),
      weeklyGoal: z2.number().int().min(1).max(3)
    }).parse(req.body), id = randomUUID();
    await tx(async (db) => {
      await db.query("INSERT INTO challenges VALUES($1,$2,$3,$4,$5,true)", [
        id,
        c.title,
        c.description,
        c.weeks,
        c.weeklyGoal
      ]);
      await db.query("INSERT INTO audit_log VALUES($1,$2,$3,$4,now())", [
        randomUUID(),
        actor,
        "challenge.create",
        id
      ]);
    });
    return { id };
  });
}
var uuid;
var init_features = __esm({
  async "apps/api/src/features.ts"() {
    "use strict";
    init_src();
    await init_db();
    uuid = z2.string().uuid();
  }
});

// apps/api/src/crypto.ts
import { scrypt as rawScrypt, randomBytes, createHash, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
async function hashPassword(password) {
  const salt = randomBytes(16).toString("hex");
  const key = await scrypt(password, salt, 64);
  return `${salt}:${key.toString("hex")}`;
}
async function verifyPassword(password, stored) {
  const [salt, key] = stored.split(":");
  if (!salt || !key) return false;
  const actual = await scrypt(password, salt, 64);
  const expected = Buffer.from(key, "hex");
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}
var scrypt, digest, token;
var init_crypto = __esm({
  "apps/api/src/crypto.ts"() {
    "use strict";
    scrypt = promisify(rawScrypt);
    digest = (value) => createHash("sha256").update(value).digest("hex");
    token = () => randomBytes(32).toString("base64url");
  }
});

// apps/api/src/server.ts
var server_exports = {};
__export(server_exports, {
  buildApp: () => buildApp
});
import Fastify from "fastify";
import cors from "@fastify/cors";
import helmet from "@fastify/helmet";
import rateLimit from "@fastify/rate-limit";
import { randomUUID as randomUUID2 } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import { z as z3, ZodError } from "zod";
function member(r) {
  if (!r.actor) throw fail(401, "Connecte-toi pour continuer.");
  return r.actor.id;
}
function admin(r) {
  member(r);
  if (r.actor?.role !== "admin") throw fail(403, "Acc\xE8s r\xE9serv\xE9 \xE0 l\u2019administration.");
  return r.actor.id;
}
async function newSession(userId) {
  const raw = token();
  await pool.query("INSERT INTO auth_sessions VALUES($1,$2,now()+interval '7 days')", [
    digest(raw),
    userId
  ]);
  return raw;
}
async function getProgram(id) {
  const row = (await pool.query("SELECT data FROM catalog WHERE id=$1 AND kind='program'", [id])).rows[0];
  if (!row) throw fail(404, "Programme introuvable.");
  return row.data;
}
async function allowed(userId, p) {
  const grants = await tx(
    (db) => db.query(
      "SELECT kind,program_id,expires_at::text FROM entitlements WHERE user_id=$1",
      [userId]
    ),
    userId
  );
  if (!canAccess("", grants.rows, p))
    throw fail(
      403,
      "Ce programme n\xE9cessite un droit d\u2019acc\xE8s. Les achats ne sont pas encore activ\xE9s."
    );
}
async function buildApp(options = {}) {
  if (process.env.NODE_ENV === "production")
    throw new Error(
      "Pilote uniquement : revue s\xE9curit\xE9, email transactionnel et configuration de production requis. Voir LAUNCH_CHECKLIST.md."
    );
  const app = Fastify({
    logger: options.testing ? false : { redact: ["req.headers.authorization"] },
    bodyLimit: 32 * 1024
  });
  await app.register(cors, {
    origin: (process.env.WEB_ORIGINS ?? "http://localhost:8081,http://127.0.0.1:8081").split(","),
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"]
  });
  await app.register(helmet);
  await app.register(rateLimit, { max: options.testing ? 1e3 : 120, timeWindow: "1 minute" });
  app.decorateRequest("actor", null);
  app.addHook("onRequest", async (req) => {
    const bearer = req.headers.authorization?.match(/^Bearer ([A-Za-z0-9_-]{43})$/)?.[1];
    if (bearer) {
      const row = (await pool.query(
        "SELECT u.id,u.role FROM auth_sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=$1 AND s.expires_at>now()",
        [digest(bearer)]
      )).rows[0];
      req.actor = row ?? null;
    }
  });
  app.setErrorHandler((error, _req, reply) => {
    const e = error;
    if (error instanceof ZodError)
      return reply.code(400).send({ message: "V\xE9rifie les champs renseign\xE9s.", fields: error.flatten().fieldErrors });
    if (e.code === "23505")
      return reply.code(409).send({ message: "Cette action existe d\xE9j\xE0 ou une s\xE9ance est d\xE9j\xE0 en cours." });
    if (e.code === "23503" || e.code === "42501")
      return reply.code(403).send({ message: "Action non autoris\xE9e ou contenu inaccessible." });
    const status = e.statusCode ?? 500;
    if (status >= 500) app.log.error({ name: e.name, code: e.code }, "Erreur serveur");
    return reply.code(status).send({ message: status >= 500 ? "Service indisponible. R\xE9essaie plus tard." : e.message });
  });
  app.get("/health", async () => {
    await pool.query("SELECT 1");
    return { ok: true, mode: "pilot", app: "MOVA" };
  });
  app.post(
    "/auth/register",
    { config: { rateLimit: { max: options.testing ? 100 : 5, timeWindow: "1 minute" } } },
    async (req) => {
      const c = credentials.extend({
        nickname: z3.string().trim().min(2).max(40),
        adult: z3.literal(true),
        terms: z3.literal(true)
      }).parse(req.body);
      const id = randomUUID2(), hash = await hashPassword(c.password);
      await tx(async (db) => {
        await db.query("INSERT INTO users(id,email,password_hash) VALUES($1,$2,$3)", [
          id,
          c.email,
          hash
        ]);
        await db.query("INSERT INTO profiles(user_id,nickname) VALUES($1,$2)", [id, c.nickname]);
        await db.query("INSERT INTO consents(user_id,terms_version) VALUES($1,'pilot-v1')", [id]);
      });
      return { token: await newSession(id) };
    }
  );
  app.post(
    "/auth/login",
    { config: { rateLimit: { max: options.testing ? 100 : 10, timeWindow: "1 minute" } } },
    async (req) => {
      const c = credentials.parse(req.body);
      const u = (await pool.query("SELECT * FROM users WHERE email=$1", [c.email])).rows[0];
      const valid = await verifyPassword(
        c.password,
        u?.password_hash ?? `${"0".repeat(32)}:${"0".repeat(128)}`
      );
      if (!u || !valid) throw fail(401, "Email ou mot de passe incorrect.");
      return { token: await newSession(u.id) };
    }
  );
  app.post("/auth/logout", async (req) => {
    member(req);
    await pool.query("DELETE FROM auth_sessions WHERE token_hash=$1", [
      digest(req.headers.authorization.slice(7))
    ]);
    return { ok: true };
  });
  app.post(
    "/auth/forgot",
    { config: { rateLimit: { max: options.testing ? 100 : 3, timeWindow: "1 minute" } } },
    async (req) => {
      const { email } = z3.object({
        email: z3.string().email().transform((s) => s.toLowerCase().trim())
      }).parse(req.body);
      const u = (await pool.query("SELECT id FROM users WHERE email=$1", [email])).rows[0];
      if (u) {
        const raw = token();
        await tx(async (db) => {
          await db.query("DELETE FROM password_resets WHERE user_id=$1", [u.id]);
          await db.query("INSERT INTO password_resets VALUES($1,$2,now()+interval '30 minutes')", [
            digest(raw),
            u.id
          ]);
        });
        if (!options.testing) {
          await mkdir(".local/mail", { recursive: true, mode: 448 });
          await writeFile(
            `.local/mail/${randomUUID2()}.json`,
            JSON.stringify({ to: email, resetToken: raw, expiresMinutes: 30 }),
            { mode: 384 }
          );
        }
      }
      return {
        message: "Si le compte existe, une demande a \xE9t\xE9 cr\xE9\xE9e. Dans ce pilote, aucun email n\u2019est envoy\xE9 : le lien est \xE9crit dans le dossier local de d\xE9veloppement de l\u2019API."
      };
    }
  );
  app.post("/auth/reset", async (req) => {
    const c = z3.object({ token: z3.string().length(43), password: z3.string().min(12).max(128) }).parse(req.body), hash = await hashPassword(c.password);
    await tx(async (db) => {
      const r = (await db.query(
        "DELETE FROM password_resets WHERE token_hash=$1 AND expires_at>now() RETURNING user_id",
        [digest(c.token)]
      )).rows[0];
      if (!r) throw fail(400, "Lien expir\xE9 ou d\xE9j\xE0 utilis\xE9.");
      await db.query("UPDATE users SET password_hash=$1 WHERE id=$2", [hash, r.user_id]);
      await db.query("DELETE FROM auth_sessions WHERE user_id=$1", [r.user_id]);
    });
    return { ok: true };
  });
  app.get("/me", async (req) => {
    const id = member(req);
    return tx(async (db) => {
      const profile = (await db.query("SELECT * FROM profiles WHERE user_id=$1", [id])).rows[0];
      const prefs = (await db.query("SELECT data FROM preferences WHERE user_id=$1", [id])).rows[0]?.data ?? null;
      const ledger = (await db.query(
        "SELECT amount,reason,created_at FROM points_ledger WHERE user_id=$1 ORDER BY created_at DESC",
        [id]
      )).rows;
      return {
        id,
        role: req.actor.role,
        profile,
        preferences: prefs,
        points: ledger.reduce((n, r) => n + r.amount, 0),
        ledger
      };
    }, id);
  });
  app.put("/me/onboarding", async (req) => {
    const id = member(req), data = onboardingSchema.parse(req.body);
    await tx(
      (db) => db.query(
        "INSERT INTO preferences VALUES($1,$2) ON CONFLICT(user_id) DO UPDATE SET data=excluded.data",
        [id, JSON.stringify(data)]
      ),
      id
    );
    return { recommendedProgramId: recommend(data) };
  });
  app.patch("/me/profile", async (req) => {
    const id = member(req), p = z3.object({ nickname: z3.string().trim().min(2).max(40), bio: z3.string().trim().max(300) }).parse(req.body);
    await tx(
      (db) => db.query("UPDATE profiles SET nickname=$1,bio=$2 WHERE user_id=$3", [
        p.nickname,
        p.bio,
        id
      ]),
      id
    );
    return { ok: true };
  });
  app.get("/me/export", async (req) => {
    const id = member(req);
    return tx(async (db) => {
      const result = {};
      for (const [table, column] of [
        ["users", "id"],
        ["consents", "user_id"],
        ["challenge_members", "user_id"],
        ["group_members", "user_id"],
        ["badges", "user_id"],
        ["saved_posts", "user_id"],
        ["profiles", "user_id"],
        ["preferences", "user_id"],
        ["workouts", "user_id"],
        ["points_ledger", "user_id"],
        ["entitlements", "user_id"],
        ["posts", "user_id"],
        ["comments", "user_id"],
        ["likes", "user_id"],
        ["follows", "follower_id"],
        ["blocks", "blocker_id"],
        ["reports", "reporter_id"]
      ]) {
        result[table] = table === "users" ? (await db.query("SELECT id,email,created_at FROM users WHERE id=$1", [id])).rows : (await db.query(`SELECT * FROM ${table} WHERE ${column}=$1`, [id])).rows;
      }
      return result;
    });
  });
  app.delete("/me", async (req) => {
    const id = member(req);
    const { password } = z3.object({ password: z3.string().min(12).max(128) }).parse(req.body);
    const u = (await pool.query("SELECT password_hash FROM users WHERE id=$1", [id])).rows[0];
    if (!u || !await verifyPassword(password, u.password_hash))
      throw fail(401, "Mot de passe incorrect.");
    await pool.query("DELETE FROM users WHERE id=$1", [id]);
    return { ok: true };
  });
  app.get("/catalog", async () => {
    const rows = (await pool.query("SELECT kind,data FROM catalog ORDER BY id")).rows;
    return {
      exercises: rows.filter((r) => r.kind === "exercise").map((r) => r.data),
      programs: rows.filter((r) => r.kind === "program").map((r) => r.data)
    };
  });
  app.get("/workouts", async (req) => {
    const id = member(req);
    return (await tx(
      (db) => db.query("SELECT * FROM workouts WHERE user_id=$1 ORDER BY started_at DESC LIMIT 100", [
        id
      ]),
      id
    )).rows;
  });
  app.post("/workouts", async (req) => {
    const id = member(req), { programId } = z3.object({ programId: z3.string(), acknowledgeDraft: z3.literal(true) }).parse(req.body);
    const p = await getProgram(programId);
    await allowed(id, p);
    const wid = randomUUID2();
    return tx(async (db) => {
      await db.query("SELECT pg_advisory_xact_lock(hashtext($1))", [id]);
      const count = Number(
        (await db.query(
          "SELECT count(*) FROM workouts WHERE user_id=$1 AND program_id=$2 AND completed_at IS NOT NULL",
          [id, p.id]
        )).rows[0].count
      );
      const step = programStep(p, count);
      const snapshot = {
        ...p,
        reps: step.reps,
        week: step.week,
        ordinal: step.ordinal,
        totalSessions: step.total,
        maintenance: step.maintenance
      };
      return (await db.query(
        "INSERT INTO workouts(id,user_id,program_id,snapshot) VALUES($1,$2,$3,$4) RETURNING *",
        [wid, id, p.id, JSON.stringify(snapshot)]
      )).rows[0];
    }, id);
  });
  app.put("/workouts/:id/sets", async (req) => {
    const id = member(req), wid = uuid2.parse(req.params.id), { sets, baseRevision } = sessionSchema.pick({ sets: true }).extend({ baseRevision: z3.number().int().min(0).default(0) }).parse(req.body);
    return tx(async (db) => {
      const w = (await db.query("SELECT * FROM workouts WHERE id=$1 AND completed_at IS NULL FOR UPDATE", [
        wid
      ])).rows[0];
      if (!w) throw fail(404, "S\xE9ance active introuvable.");
      if (w.revision !== baseRevision)
        throw fail(
          409,
          "Cette s\xE9ance a chang\xE9 sur un autre appareil. Recharge la version serveur."
        );
      const p = w.snapshot;
      if (sets.some((s) => !p.exerciseIds.includes(s.exerciseId) || s.index >= p.sets) || new Set(sets.map((s) => `${s.exerciseId}:${s.index}`)).size !== sets.length)
        throw fail(400, "S\xE9ries invalides.");
      return (await db.query("UPDATE workouts SET sets=$1,revision=revision+1 WHERE id=$2 RETURNING *", [
        JSON.stringify(sets),
        wid
      ])).rows[0];
    }, id);
  });
  app.post("/workouts/:id/finish", async (req) => {
    const id = member(req), wid = uuid2.parse(req.params.id);
    return tx(async (db) => {
      await db.query("SELECT pg_advisory_xact_lock(hashtext($1))", [id]);
      await db.query("SELECT id FROM users WHERE id=$1 FOR UPDATE", [id]);
      const w = (await db.query("SELECT * FROM workouts WHERE id=$1 AND user_id=$2 FOR UPDATE", [wid, id])).rows[0];
      if (!w) throw fail(404, "S\xE9ance introuvable.");
      const reward = (await db.query("SELECT amount FROM points_ledger WHERE workout_id=$1", [wid])).rows[0];
      if (w.completed_at) return { workout: w, points: reward?.amount ?? 0 };
      if (!validateCompletedSets(w.snapshot, w.sets))
        throw fail(400, "Enregistre toutes les s\xE9ries avant de terminer.");
      if (Date.now() - new Date(w.started_at).getTime() < 3e4)
        throw fail(400, "Une s\xE9ance doit durer au moins 30 secondes pour \xEAtre termin\xE9e.");
      const n = Number(
        (await db.query(
          "SELECT count(*) FROM points_ledger WHERE user_id=$1 AND amount>0 AND created_at >= date_trunc('week',now() AT TIME ZONE 'Europe/Paris') AT TIME ZONE 'Europe/Paris'",
          [id]
        )).rows[0].count
      );
      const today = Number(
        (await db.query(
          "SELECT count(*) FROM points_ledger WHERE user_id=$1 AND amount>0 AND (created_at AT TIME ZONE 'Europe/Paris')::date=(now() AT TIME ZONE 'Europe/Paris')::date",
          [id]
        )).rows[0].count
      );
      const amount = n < 3 && today === 0 ? 50 : 0;
      const finished = (await db.query("UPDATE workouts SET completed_at=now() WHERE id=$1 RETURNING *", [wid])).rows[0];
      await db.query("INSERT INTO points_ledger VALUES($1,$2,$3,$4,$5,now())", [
        randomUUID2(),
        id,
        wid,
        amount,
        amount ? "S\xE9ance termin\xE9e" : "S\xE9ance termin\xE9e \xB7 plafond de points atteint"
      ]);
      await awardBadges(db, id);
      return { workout: finished, points: amount };
    });
  });
  app.get("/feed", async (req) => {
    const id = member(req), q = z3.object({
      before: z3.string().datetime({ offset: true }).optional(),
      beforeId: uuid2.optional(),
      scope: z3.enum(["community", "following"]).default("community")
    }).refine((q2) => !!q2.before === !!q2.beforeId).parse(req.query);
    return tx(async (db) => {
      return (await db.query(
        `SELECT p.id,p.user_id,p.body,p.created_at,pr.nickname,
   (SELECT count(*)::int FROM likes l WHERE l.post_id=p.id) likes,
   EXISTS(SELECT 1 FROM likes l WHERE l.post_id=p.id AND l.user_id=$1) liked,
   EXISTS(SELECT 1 FROM follows f WHERE f.followed_id=p.user_id AND f.follower_id=$1) following
   FROM posts p JOIN profiles pr ON pr.user_id=p.user_id WHERE p.group_id IS NULL AND ($2::timestamptz IS NULL OR (p.created_at,p.id)<($2::timestamptz,$4::uuid))
   AND ($3='community' OR p.user_id=$1 OR EXISTS(SELECT 1 FROM follows f WHERE f.followed_id=p.user_id AND f.follower_id=$1))
   ORDER BY p.created_at DESC,p.id DESC LIMIT 20`,
        [id, q.before ?? null, q.scope, q.beforeId ?? null]
      )).rows;
    }, id);
  });
  app.get("/posts/:id", async (req) => {
    const id = member(req), pid = uuid2.parse(req.params.id);
    return tx(async (db) => {
      const p = (await db.query(
        "SELECT p.id,p.user_id,p.body,p.created_at,p.group_id,pr.nickname FROM posts p JOIN profiles pr ON pr.user_id=p.user_id WHERE p.id=$1",
        [pid]
      )).rows[0];
      if (!p) throw fail(404, "Publication inaccessible.");
      return p;
    }, id);
  });
  app.post("/posts", async (req) => {
    const id = member(req), { body } = z3.object({ body: z3.string().trim().min(1).max(1500) }).parse(req.body);
    return tx(
      async (db) => (await db.query("INSERT INTO posts(id,user_id,body) VALUES($1,$2,$3) RETURNING *", [
        randomUUID2(),
        id,
        body
      ])).rows[0],
      id
    );
  });
  app.get("/posts/:id/comments", async (req) => {
    const id = member(req), pid = uuid2.parse(req.params.id);
    return (await tx(
      (db) => db.query(
        "SELECT c.id,c.body,c.created_at,p.nickname FROM comments c JOIN profiles p ON p.user_id=c.user_id WHERE c.post_id=$1 ORDER BY c.created_at LIMIT 100",
        [pid]
      ),
      id
    )).rows;
  });
  app.post("/posts/:id/comments", async (req) => {
    const id = member(req), pid = uuid2.parse(req.params.id), { body } = z3.object({ body: z3.string().trim().min(1).max(500) }).parse(req.body);
    await tx(
      (db) => db.query("INSERT INTO comments VALUES($1,$2,$3,$4,now())", [randomUUID2(), pid, id, body]),
      id
    );
    return { ok: true };
  });
  app.put("/posts/:id/like", async (req) => {
    const id = member(req), pid = uuid2.parse(req.params.id), { liked } = z3.object({ liked: z3.boolean() }).parse(req.body);
    await tx(
      (db) => liked ? db.query("INSERT INTO likes VALUES($1,$2) ON CONFLICT DO NOTHING", [pid, id]) : db.query("DELETE FROM likes WHERE post_id=$1 AND user_id=$2", [pid, id]),
      id
    );
    return { ok: true };
  });
  app.delete("/posts/:id", async (req) => {
    const id = member(req), pid = uuid2.parse(req.params.id);
    await tx((db) => db.query("DELETE FROM posts WHERE id=$1 AND user_id=$2", [pid, id]), id);
    return { ok: true };
  });
  app.put("/members/:id/follow", async (req) => {
    const id = member(req), other = uuid2.parse(req.params.id), { following } = z3.object({ following: z3.boolean() }).parse(req.body);
    if (id === other) throw fail(400, "Action impossible sur ton propre profil.");
    await tx(
      (db) => following ? db.query("INSERT INTO follows VALUES($1,$2) ON CONFLICT DO NOTHING", [id, other]) : db.query("DELETE FROM follows WHERE follower_id=$1 AND followed_id=$2", [id, other]),
      id
    );
    return { ok: true };
  });
  app.post("/blocks", async (req) => {
    const id = member(req), { userId } = z3.object({ userId: uuid2 }).parse(req.body);
    if (id === userId) throw fail(400, "Action impossible sur ton propre profil.");
    await tx(async (db) => {
      await db.query("INSERT INTO blocks VALUES($1,$2) ON CONFLICT DO NOTHING", [id, userId]);
      await db.query("DELETE FROM follows WHERE follower_id=$1 AND followed_id=$2", [id, userId]);
    }, id);
    return { ok: true };
  });
  app.post("/reports", async (req) => {
    const id = member(req), r = z3.object({ postId: uuid2, reason: z3.string().trim().min(5).max(500) }).parse(req.body);
    await tx(
      (db) => db.query("INSERT INTO reports(id,reporter_id,post_id,reason) VALUES($1,$2,$3,$4)", [
        randomUUID2(),
        id,
        r.postId,
        r.reason
      ]),
      id
    );
    return { ok: true };
  });
  app.get("/billing", async (req) => {
    const id = member(req);
    return {
      enabled: false,
      message: "Achats et restauration indisponibles dans le pilote.",
      entitlements: (await tx(
        (db) => db.query("SELECT kind,program_id,expires_at FROM entitlements WHERE user_id=$1", [id]),
        id
      )).rows
    };
  });
  app.get("/admin/overview", async (req) => {
    admin(req);
    const counts = {};
    for (const table of ["users", "workouts", "posts", "reports"])
      counts[table] = Number((await pool.query(`SELECT count(*) FROM ${table}`)).rows[0].count);
    return {
      counts,
      reports: (await pool.query(
        "SELECT r.id,r.post_id,r.reason,r.state,r.created_at,p.body FROM reports r LEFT JOIN posts p ON p.id=r.post_id WHERE r.state='open' ORDER BY r.created_at LIMIT 100"
      )).rows
    };
  });
  app.post("/admin/reports/:id/resolve", async (req) => {
    const actor = admin(req), id = uuid2.parse(req.params.id), { hide } = z3.object({ hide: z3.boolean() }).parse(req.body);
    await tx(async (db) => {
      const r = (await db.query("UPDATE reports SET state='resolved' WHERE id=$1 RETURNING post_id", [id])).rows[0];
      if (!r) throw fail(404, "Signalement introuvable.");
      if (hide) await db.query("UPDATE posts SET hidden=true WHERE id=$1", [r.post_id]);
      await db.query("INSERT INTO audit_log VALUES($1,$2,$3,$4,now())", [
        randomUUID2(),
        actor,
        hide ? "report.hide" : "report.resolve",
        id
      ]);
    });
    return { ok: true };
  });
  app.patch("/admin/catalog/:id", async (req) => {
    const actor = admin(req), id = z3.string().max(50).parse(req.params.id);
    const patch = z3.object({
      name: z3.string().trim().min(3).max(100).optional(),
      sets: z3.number().int().min(1).max(4).optional(),
      reps: z3.number().int().min(3).max(20).optional(),
      rest: z3.number().int().min(30).max(180).optional(),
      instructions: z3.array(z3.string().min(5).max(500)).min(1).max(8).optional(),
      safety: z3.string().min(10).max(500).optional()
    }).strict().parse(req.body);
    await tx(async (db) => {
      const row = (await db.query("SELECT * FROM catalog WHERE id=$1 FOR UPDATE", [id])).rows[0];
      if (!row) throw fail(404, "Contenu introuvable.");
      if (row.kind === "exercise" && (patch.sets || patch.reps || patch.rest))
        throw fail(400, "Champs de programme interdits sur un exercice.");
      if (row.kind === "program" && (patch.instructions || patch.safety))
        throw fail(400, "Champs d\u2019exercice interdits sur un programme.");
      await db.query("UPDATE catalog SET data=$1,updated_at=now() WHERE id=$2", [
        JSON.stringify({ ...row.data, ...patch, status: "pending_review" }),
        id
      ]);
      await db.query("INSERT INTO audit_log VALUES($1,$2,$3,$4,now())", [
        randomUUID2(),
        actor,
        "catalog.edit",
        id
      ]);
    });
    return { ok: true };
  });
  await registerFeatures(app, { member, admin, fail });
  return app;
}
var uuid2, credentials, fail;
var init_server = __esm({
  async "apps/api/src/server.ts"() {
    "use strict";
    init_src();
    await init_db();
    await init_features();
    init_crypto();
    uuid2 = z3.string().uuid();
    credentials = z3.object({
      email: z3.string().email().max(254).transform((s) => s.toLowerCase().trim()),
      password: z3.string().min(12).max(128)
    });
    fail = (statusCode, message) => Object.assign(new Error(message), { statusCode });
  }
});

// scripts/personal.ts
import { fileURLToPath as fileURLToPath2 } from "node:url";
import { dirname, join as join2, resolve as resolve2 } from "node:path";
import { mkdir as mkdir2, readFile as readFile3, open, unlink } from "node:fs/promises";
import { spawn } from "node:child_process";
import { createServer } from "node:net";

// scripts/desktop-gateway.ts
import http from "node:http";
import { readFile, stat } from "node:fs/promises";
import { resolve, sep, extname } from "node:path";
var mime = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".json": "application/json",
  ".ttf": "font/ttf"
};
function desktopGateway(app, rootPath) {
  const root = resolve(rootPath);
  return http.createServer(async (req, res) => {
    try {
      const port = res.socket?.localAddress && res.socket.localPort || 8080;
      const hosts = [`localhost:${port}`, `127.0.0.1:${port}`];
      if (!hosts.includes(req.headers.host ?? "")) {
        res.writeHead(403).end("H\xF4te non autoris\xE9");
        return;
      }
      const url = new URL(req.url ?? "/", "http://localhost");
      if (url.pathname.startsWith("/api/")) {
        if (req.headers.origin && !hosts.some((h) => req.headers.origin === `http://${h}`)) {
          res.writeHead(403).end("Origine non autoris\xE9e");
          return;
        }
        let size = 0;
        const chunks = [];
        if (Number(req.headers["content-length"] ?? 0) > 32768) {
          res.writeHead(413, { Connection: "close" }).end("Requ\xEAte trop volumineuse");
          req.resume();
          return;
        }
        for await (const chunk of req) {
          size += chunk.length;
          if (size > 32768) {
            res.writeHead(413).end("Requ\xEAte trop volumineuse");
            return;
          }
          chunks.push(Buffer.from(chunk));
        }
        const result = await app.inject({
          method: req.method,
          url: url.pathname.slice(4) + url.search,
          headers: req.headers,
          payload: chunks.length ? Buffer.concat(chunks) : void 0
        });
        res.writeHead(result.statusCode, result.headers);
        res.end(result.rawPayload);
        return;
      }
      if (!["GET", "HEAD"].includes(req.method ?? "")) {
        res.writeHead(405).end();
        return;
      }
      const decoded = decodeURIComponent(url.pathname);
      const file = resolve(root, "." + decoded);
      if (file !== root && !file.startsWith(root + sep) || decoded.split("/").some((s) => s.startsWith("."))) {
        res.writeHead(404).end();
        return;
      }
      let target = file;
      try {
        if (!(await stat(target)).isFile()) target = resolve(root, "index.html");
      } catch {
        if (extname(file)) {
          res.writeHead(404).end();
          return;
        }
        target = resolve(root, "index.html");
      }
      const body = await readFile(target);
      res.writeHead(200, {
        "Content-Type": mime[extname(target)] ?? "application/octet-stream",
        "Content-Length": body.length,
        "X-Content-Type-Options": "nosniff",
        "Cache-Control": extname(target) === ".html" ? "no-store" : "public, max-age=3600"
      });
      res.end(req.method === "HEAD" ? void 0 : body);
    } catch {
      if (!res.headersSent) res.writeHead(500);
      res.end("Service local indisponible");
    }
  });
}

// scripts/personal.ts
async function main() {
  const root = process.env.MOVA_RELEASE_ROOT ? resolve2(process.env.MOVA_RELEASE_ROOT) : dirname(fileURLToPath2(import.meta.url));
  process.chdir(root);
  const port = Number(process.env.MOVA_DESKTOP_PORT ?? 8080);
  if (!Number.isInteger(port) || port < 1024 || port > 65535)
    throw new Error("Le port MOVA doit \xEAtre compris entre 1024 et 65535.");
  const address = `http://127.0.0.1:${port}`;
  function browse() {
    if (process.env.MOVA_OPEN_BROWSER === "0") return;
    const child = process.platform === "win32" ? spawn("cmd", ["/c", "start", "", address]) : process.platform === "darwin" ? spawn("open", [address]) : spawn("xdg-open", [address]);
    child.on("error", () => console.log(`Ouvrez ${address} dans votre navigateur.`));
    child.unref();
  }
  try {
    const response = await fetch(address + "/api/health", { signal: AbortSignal.timeout(800) });
    if (response.ok && (await response.json()).app === "MOVA") {
      console.log(`MOVA est d\xE9j\xE0 ouvert : ${address}`);
      browse();
      return;
    }
  } catch {
  }
  const probe = createServer();
  await new Promise((done, reject) => {
    probe.once(
      "error",
      () => reject(new Error(`Le port ${port} est occup\xE9 par une autre application.`))
    );
    probe.listen(port, "127.0.0.1", () => probe.close(() => done()));
  });
  const userRoot = process.env.MOVA_LOCAL_DATA_DIR ? resolve2(process.env.MOVA_LOCAL_DATA_DIR) : process.platform === "win32" && process.env.LOCALAPPDATA ? join2(process.env.LOCALAPPDATA, "MOVA-Pilote") : join2(root, "..", "mova-personal-data");
  await mkdir2(userRoot, { recursive: true });
  const lockFile = join2(userRoot, "application.lock");
  async function takeLock() {
    try {
      const file = await open(lockFile, "wx", 384);
      await file.writeFile(String(process.pid));
      await file.close();
    } catch (e) {
      if (e.code !== "EEXIST") throw e;
      let pid = Number.NaN;
      try {
        pid = Number(await readFile3(lockFile, "utf8"));
      } catch {
        throw new Error(
          "Le verrou local est illisible. Fermez MOVA et v\xE9rifiez le dossier de donn\xE9es."
        );
      }
      let alive = true;
      if (Number.isInteger(pid) && pid > 0) {
        try {
          process.kill(pid, 0);
        } catch (error) {
          if (error.code === "ESRCH") alive = false;
        }
      }
      if (alive)
        throw new Error(
          "Une autre instance MOVA utilise d\xE9j\xE0 ces donn\xE9es. Fermez-la avant de changer de port."
        );
      await unlink(lockFile);
      const file = await open(lockFile, "wx", 384);
      await file.writeFile(String(process.pid));
      await file.close();
    }
  }
  await takeLock();
  process.env.MOVA_DATABASE_ENGINE = "embedded";
  process.env.MOVA_LOCAL_DATA_DIR = join2(userRoot, "database");
  process.env.MOVA_MIGRATIONS_DIR = join2(root, "database");
  process.env.WEB_ORIGINS = `${address},http://localhost:${port}`;
  console.log("MOVA \xB7 ouverture de votre espace personnel\u2026");
  const { pool: pool2 } = await init_db().then(() => db_exports);
  let closing = false;
  let stopServer = () => {
  };
  let closeApp = async () => {
  };
  async function close() {
    if (closing) return;
    closing = true;
    stopServer();
    await closeApp();
    await pool2.end();
    await unlink(lockFile).catch(() => {
    });
  }
  try {
    const { migrate: migrate2 } = await init_migrate().then(() => migrate_exports);
    await migrate2();
    const { buildApp: buildApp2 } = await init_server().then(() => server_exports);
    const app = await buildApp2();
    await app.ready();
    closeApp = () => app.close();
    const server = desktopGateway(app, join2(root, "web"));
    stopServer = () => {
      server.close();
      server.closeIdleConnections();
    };
    await new Promise((done, reject) => {
      server.once("error", reject);
      server.listen(port, "127.0.0.1", done);
    });
    console.log(
      `
MOVA est pr\xEAt : ${address}
Aucune installation de Node.js ou Docker requise dans la version Windows portable.
Vos donn\xE9es restent sur cet ordinateur. Gardez cette fen\xEAtre ouverte. Ctrl+C pour quitter.
`
    );
    browse();
    for (const signal of ["SIGINT", "SIGTERM"])
      process.on(signal, () => {
        close().then(() => process.exit(0)).catch(() => process.exit(1));
      });
  } catch (e) {
    await close();
    throw e;
  }
}
main().catch((error) => {
  console.error(`MOVA n\u2019a pas pu d\xE9marrer : ${error.message}`);
  process.exitCode = 1;
});
